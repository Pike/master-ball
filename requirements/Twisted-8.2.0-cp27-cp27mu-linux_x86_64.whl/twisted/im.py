from twisted.python import util

util.moduleMovedForSplit('twisted.im', 'twisted.words.im',
                         'Instance Messenger', 'Words',
                         'http://projects.twistedmatrix.com/words',
                         globals())
