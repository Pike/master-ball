from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.msn', 'twisted.words.protocols.msn',
                         'MSN protocol support', 'Words',
                         'http://twistedmatrix.com/trac/wiki/TwistedWords',
                         globals())

